<?php

namespace App\Support;

use App\Models\Qdn;

/**
 * Per-request "you have N pending" counts for the sidebar nav badges --
 * Issued (QDNs for My Department), Dept: RCA, Dept: CAPA, Dept: Approval,
 * QA Verification. Shared to every Inertia page via
 * App\Http\Middleware\AuthMiddleware (see the two `Inertia::share(...)`
 * calls added there), so NavLinks.jsx can read `qdnCounts` from
 * usePage().props on any screen, not just the queue pages themselves.
 *
 * Each count deliberately mirrors the exact same scoping its
 * corresponding index page already uses (see
 * QdnWorkflowController::rcaIndex/capaIndex/approvalIndex/qaIndex and
 * IssuedQdnController::index) -- one definition of "what's in this
 * queue," so the badge number never drifts out of sync with what you
 * actually see after clicking it.
 */
class QdnNotificationCounts
{
    public static function forCurrentEmployee(): array
    {
        $department = CurrentEmployee::department();

        return [
            // "QDNs for My Department" is a whole-lifecycle status board
            // (Qdn::DEPARTMENT_VISIBLE_STATUSES, issued through closed),
            // not a single action queue -- RCA/CAPA/Approval below already
            // cover "needs your action right now," so this one is the
            // department's overall still-open count (everything except
            // the two terminal statuses).
            'issued' => $department
                ? Qdn::whereIn('status', Qdn::DEPARTMENT_VISIBLE_STATUSES)
                    ->whereNotIn('status', [Qdn::STATUS_CLOSED, Qdn::STATUS_INVALID_DISPOSITION])
                    ->where('issued_department', $department)
                    ->count()
                : 0,

            'rca' => $department
                ? Qdn::where('status', Qdn::STATUS_FOR_DEPT_RCA)
                    ->where('issued_department', $department)
                    ->count()
                : 0,

            'capa' => $department
                ? Qdn::where('status', Qdn::STATUS_FOR_DEPT_CAPA)
                    ->where('issued_department', $department)
                    ->count()
                : 0,

            'approval' => $department
                ? Qdn::where('status', Qdn::STATUS_FOR_DEPT_APPROVAL)
                    ->where('issued_department', $department)
                    ->count()
                : 0,

            // Not department-scoped -- same shared-queue model as
            // QdnWorkflowController::qaIndex (any Department: QA employee
            // sees every QDN awaiting verification, not just their own
            // department's). Zero for everyone else so the badge never
            // shows on QA Verification for people who can't even see that
            // link (NavLinks already hides it behind isQa).
            'qaVerification' => CurrentEmployee::isQa()
                ? Qdn::where('status', Qdn::STATUS_FOR_QA_VERIFICATION)->count()
                : 0,
        ];
    }
}
